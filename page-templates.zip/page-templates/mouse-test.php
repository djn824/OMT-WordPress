<?php /* Template Name:Mouse*/
get_header();?>
<div class="camera-test">
								<div class="webcam-1 dis-flex sm-dis-block">
									<div class="width-48 pad-left-15 wid-sm-100 wid-xs-100">
										<div class="ct-row mar-bot-15 dis-flex">
											<div class="webcam-1-icon_">
												<div class="webcam-icon">
													<img class="tve_image" alt="" style="width: 50px;" src="<?php the_field('mouse_icon');?>" width="50" height="50">
												</div>
											</div>
											<div class="webcam-1-text_">
												<div class="icon-text-1">
													<h3 class="ct-bold-text"><?php the_field('get_easily_started_title');?></h3>
												</div>
											</div>
										</div>
										<div class="ct-row">
											<div class="new-webcam-desc">
												<ul>
													<?php

												// check if the repeater field has rows of data
												if( have_rows('get_easily_started_steps') ):

												 	// loop through the rows of data
									    		while ( have_rows('get_easily_started_steps') ) : the_row();?>
													<li>
														<span><?php the_sub_field('numbers');?></span>
														<div>
															<strong><?php the_sub_field('title');?></strong>
														</div>
													</li>
													<?php endwhile;
														else :
														endif;
														?>
													<!-- <li>
														<span>2</span>
														<strong>Point your mouse cursor at the mouse illustration and then spin the scroll wheel on your mouse up and down.</strong>
													</li>
													<li>
														<span>3</span><strong>Check if the arrows on the illustration also light up.</strong>
													</li> -->
												</ul>
											</div>
										</div>
										<div class="ct-row">
											<div class="mic-work-not">
													<p><?php the_field('red_notice');?></p>
												</div>
										</div>
									</div>
									<div class="width-40_2 pad-left-15 wid-sm-100 wid-xs-100">
										<div class="ct-row web-test-res dis-flex">
											<div class="webcam-2-icon_">
												<div class="webcam-icon">
													<img class="tve_image" alt="" style="width: 50px;" src="<?php the_field('mouse_icon');?>" data-attachment-id="8499" width="50" height="50">
												</div>
											</div>
											<div class="webcam-2-text_">
												<div class="icon-text-1">
													<h3 class="ct-bold-text"><?php the_field('the_test_title');?></h3>
												</div>
											</div>
										</div>

										<div class="mouse-section">

											<style>

												.mouse-section { text-align: center; }

												#mouse { width: 100%; height: 100%; max-width: 800px; }

												#mouse .visited { fill: #cae1ff!important; }

												#mouse .active { fill: #73a9ef!important; }

												.trouble-shooting { margin-top: -45px; }
												
												#gamepad_choice {
													padding: 5px 6px;
													border-radius: 5px;
													color: #436f8e;
													border: 1px solid #436f8e;
													font-size: 16px;
													min-width: 100px;
												}
												
												@media (max-width: 768px){
													.trouble-shooting-2 {
													    display: block !important;
													}
												}

											</style>


											<svg id="mouse" viewBox="0.917 0.331 2000 2000" width="2000" height="2000" xmlns="http://www.w3.org/2000/svg" xmlns:bx="https://boxy-svg.com">

												<polygon style="fill: rgb(255, 255, 255);" points="762.901 533.207 837.19 479.736 979.666 414.532 1106.875 384.189 1209.716 377.437 1336.374 393.357 1409.585 417.127 1476.487 452.71 1541.071 500.431 1593.42 556.291 1627.7 603.9 1668.307 684.194 1690.246 795.184 1685.87 883.063 1669.446 951.085 1639.021 1018.645 1594.49 1077.762 1391.745 1167.637 1293.837 1222.122 1236.579 1262.911 1104.818 1380.372 985.532 1496.323 844.926 1513.217 551.153 1425.339 374.566 1163.246 365.254 1124.956 361.399 958.497 446.68 838.481 549.264 720.013 664.397 607.513"/>

												<polygon id="mouse-1" style="fill: rgb(255, 255, 255);" points="610.236 1317 792.977 1058.66 1005.542 773.958 1078.992 695.296 1190.432 660.797 1294.852 814.227 1348.032 924.339 982.406 1370.02 817.005 1420.91 605.79 1360.91"/>

												<polygon id="mouse-2" style="fill: rgb(255, 255, 255);" points="459.432 1258.302 458.32 1234.725 621.698 1030.215 837.618 782.876 949.843 672.314 998.034 635.495 1015.703 557.266 789.408 529.271 740.344 546.192 622.891 645.612 508.993 762.294 413.651 882.575 361.77 959.442 365.604 1133.119"/>

												<polygon id="mouse-3" style="fill: rgb(255, 255, 255);" points="630.999 1090.223 646.047 1021.603 693.549 943.689 751.401 889.029 789.846 869.447 831.479 851.575 892.346 888.88 887.499 911.834 715.323 1122.092 694.379 1130.985 677.718 1123.949 662.842 1106.245"/>

												<polygon id="mouse-4" style="fill: rgb(255, 255, 255);" points="1260.276 1036.151 1395.09 858.858 1393.892 882.938 1377.961 925.571 1285.369 1053.932"/>

												<polygon id="mouse-5" style="fill: rgb(255, 255, 255);" points="1243.645 1054.638 1262.324 1062.141 1274.192 1074.556 1158.893 1231.773 1093.133 1241.791"/>

												<g id="Layer_2" transform="matrix(3.356383, 0, 0, 3.356383, 1.583374, -0.157645)" style="">

													<path class="st0" d="M107.7,335l-1-49.5c0,0,132-217,301.5-165c0,0,67,19,88,88s-22.5,112-22.5,112s-54.1,22.6-73.8,34 c-10.8,6.3-25,14-46.3,33c-22.4,20-61.5,58-61.5,58l-42,5L162.7,424l-52-78.5L107.7,335z" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 3px;"/>

													<path class="st0" d="M473.6,165.7c0,0-3.3-0.7-9.3,9c-6,9.7-44,74.3-62.3,98.3S292.3,410,292.3,410s-21.7,3.8-45.2,11.6 c-2.1,0.7-4.3,0.8-6.5,0.2c-15-3.8-76.3-19.6-92.3-27.5L107.7,335" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 3px;"/>

													<path class="st1" d="M272.4,414.4l10.7,23.3l13.2-2.9l61.2-56.8c0,0,23.6-20.4,50.6-32.8c24-11,71-31.3,71-31.3" style="fill: none; stroke: rgb(67, 112, 143); stroke-miterlimit: 10; stroke-width: 2px;"/>

													<path class="st2" d="M324.5,370.1l18.9-2.9l61.8-85.5c0,0,11-16,8.9-25.9" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

													<path class="st2" d="M369.3,314c0,0,5.6,0.6,8.5,5.1" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

													<path class="st2" d="M373.4,308.9c0,0,5.3,0.3,8.3,5.3" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

													<path class="st3" d="M354.7,196.8c0,0,30.7,43.6,32.5,48.5c4.3,11.5,13.9,29,13.9,29" style="fill: none; stroke: rgb(67, 112, 143); stroke-miterlimit: 10; stroke-width: 3px;"/>

													<path class="st3" d="M180.1,405.3v-7.7c0,0,97.1-146.3,138.6-188.7c1.5-1.5,3.3-2.6,5.3-3.2l30.7-9c0,0,27.7-46.5,64-61.8 c2.2-0.9,2.9-3.8,1.4-5.6c-3.7-4.4-12.4-10-32.1-5.9c-29.8,6.3-56.4,17.9-86.9,42.2c0,0-2.2-2-13.4-2.2c-11.2-0.2-36.7-4.5-43.5-5 c-6.8-0.5-11.6-1.8-23.1,3.1" style="fill: none; stroke: rgb(67, 112, 143); stroke-miterlimit: 10; stroke-width: 3px;"/>

													<path class="st3" d="M135,374.9V369c0,0,97.6-129.2,157.5-176.9c2.2-1.8,3.7-4.2,4.3-6.9l4.2-19.5" style="fill: none; stroke: rgb(67, 112, 143); stroke-miterlimit: 10; stroke-width: 3px;"/>

													<g>

														<path class="st4" d="M113.7,338.8c3.2,3.9,6.3,7.9,9.4,11.9l4.7,6c0.8,1,1.6,2,2.3,3l2.2,3.1l17.9,24.5l-0.5-0.4l62.5,17.9 l15.6,4.5l7.8,2.2c0.6,0.2,1.3,0.4,1.9,0.5c0.6,0.1,1.2,0.2,1.8,0.2c1.2,0,2.5-0.2,3.6-0.6c10-3.9,20-8.2,30.3-11.7l0.2-0.1 l0.2,0.1c2.7,1,5.4,2.1,8.1,3.3c2.7,1.2,5.3,2.4,7.9,3.8c-2.7-1.2-5.4-2.2-8.2-3.2c-2.7-1-5.5-1.9-8.3-2.7l0.4,0 c-5,2.2-9.9,4.5-14.9,6.4l-15.1,6c-1.4,0.5-2.9,0.7-4.4,0.7c-0.7,0-1.5-0.1-2.2-0.3c-0.8-0.2-1.3-0.4-2-0.6l-7.8-2.2l-15.6-4.5 l-62.5-17.9l-0.3-0.1l-0.2-0.3l-17.9-24.5l-2.3-3c-0.7-1-1.4-2.1-2.1-3.1l-4.2-6.3C119.3,347.2,116.5,343,113.7,338.8z" style="fill: rgb(67, 112, 143);"/>

													</g>

													<path class="st2" d="M187.7,324.4c0,0,2-28.6,23-48.6c17.8-16.9,31.8-21.1,35.7-22c0.7-0.2,1.4,0,2,0.3l16.6,10.4 c0,0-46.9,11.9-56.1,71.1" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

													<path class="st2" d="M262.1,262.9c0,0-17.7,0.1-37.4,24.6S203.2,336,203.2,336" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

													<path class="st2" d="M236.2,257.3c0,0,2.5-4.5,4.5-6s6.3-3.5,11.5-0.3s12.3,7.3,13.3,12.5s-7,13-7.8,13.5s-31.5,39.5-43,54.5 c0,0-6,6.8-10.5,4.8s-6.3-7.3-11-9s-8.3-4.3-8.3-6.8s1.8-5,4.5-7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

													<g>

														<path class="st4" d="M189.4,332.5c-1.3,2.1-2.8,4.2-4.1,6.3l-4.5,6l-9.1,11.9l-9.1,11.9l-4.5,6c-1.6,1.9-3.3,3.8-4.9,5.7 c1.3-2.1,2.8-4.2,4.1-6.3l4.5-6l9.1-11.9l9.1-11.9l4.5-6C186.1,336.3,187.7,334.4,189.4,332.5z" style="fill: rgb(67, 112, 143);"/>

													</g>

													<line class="st5" x1="197" y1="302" x2="207.7" y2="308.7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="201.7" y1="292.8" x2="212.3" y2="299.5" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="207.8" y1="284.2" x2="218.5" y2="290.8" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="214.3" y1="277" x2="225" y2="283.7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="220.8" y1="270.3" x2="231.5" y2="277" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="228.3" y1="265" x2="237.5" y2="270.5" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="236" y1="261.2" x2="243.8" y2="266.2" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="242.5" y1="258.2" x2="249.7" y2="262.8" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<g>

														<path class="st4" d="M272.6,399.9c26.2-33.8,52.1-68,77.4-102.5c12.6-17.3,25.1-34.7,37.4-52.2l9.1-13.3c3-4.4,5.9-8.9,8.9-13.4 l2.2-3.4l2.1-3.4l4.3-6.8c1.5-2.2,2.8-4.6,4.1-6.9l4-7l-3.9,7c-1.3,2.3-2.6,4.7-4,6.9l-4.2,6.8l-2.1,3.4l-2.2,3.4 c-2.9,4.5-5.8,9-8.8,13.5l-9,13.3c-12.1,17.7-24.5,35.2-37,52.6c-25.1,34.7-50.7,69.1-76.6,103.2c-0.3,0.4-1,0.5-1.4,0.2 C272.4,401,272.3,400.3,272.6,399.9L272.6,399.9z" style="fill: rgb(67, 112, 143);"/>

													</g>

													<g>

														<path class="st4" d="M243.3,424.5c1.5,3.7,2.7,7.5,3.8,11.3c1.1,3.8,2.1,7.6,2.9,11.6c-1.5-3.7-2.7-7.5-3.8-11.3 C245.1,432.2,244.1,428.4,243.3,424.5z" style="fill: rgb(67, 112, 143);"/>

													</g>

													<g>

														<defs>

															<path id="SVGID_1_" d="M337.4,375c-0.5-0.5-0.8,6.3-0.8,6.3s-1,5.5,4.3,4s23.3-27,69-45.8s63.9-34.8,72.8-49.3 c4.9-8,18.5-39.8,3.3-69.5s-29.7-6.8-32.7-2.3s-22.7,34.8-41.5,62.8c-19.3,28.8-52.2,73.6-61.8,84.8 C341.2,376.2,339.2,376.8,337.4,375z"/>

														</defs>

														<clipPath id="SVGID_2_">

															<path d="M 337.4 375 C 336.9 374.5 336.6 381.3 336.6 381.3 C 336.6 381.3 335.6 386.8 340.9 385.3 C 346.2 383.8 364.2 358.3 409.9 339.5 C 455.6 320.7 473.8 304.7 482.7 290.2 C 487.6 282.2 501.2 250.4 486 220.7 C 470.8 191 456.3 213.9 453.3 218.4 C 450.3 222.9 430.6 253.2 411.8 281.2 C 392.5 310 359.6 354.8 350 366 C 341.2 376.2 339.2 376.8 337.4 375 Z" style="overflow: visible;"/>

														</clipPath>

														<g class="st6" style="clip-path: url(#SVGID_2_);">

															<path class="st2" d="M471.5,201.3c0,0,17.2,46.3,22.7,56.5" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M466,200.5c0,0,7.5,24,10.7,32.5c3.2,8.5,15.2,34.2,16.7,37" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M460.8,201c0,0,10.1,30.7,15,43.7c4.8,13,12.1,28.1,14.2,34.6" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M457.4,204.1c0,0,3.4,12.5,6.5,23.8s7.6,25.7,12.1,34.8c4.5,9.1,9.1,19.2,10.8,24.4" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M453.5,208.8c0,0,6.1,29.4,13.8,48.2c7.6,18.8,13.2,30.2,15.5,36.3" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M449.6,214c0,0,5,27.9,10.1,41.2c5,13.2,16,35.2,19.2,44.3" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M445.7,218.7c0,0,3.2,24.6,9.9,43.9c6.7,19.4,14.3,33.9,18.1,42.3" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M442.1,223.5c0,0,2.8,28.9,9.5,48c6.7,19.2,18.8,37.4,19,38" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M437.7,229.5c0,0,2.4,27.6,7.8,43.9c5.4,16.4,15.3,32.6,19.4,39.8" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M433.6,235.8c0,0,1.5,28.9,7.1,45.1c7.4,21.8,15.6,33.1,17.3,36.5" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M429.3,241.7c0,0,0.6,28.9,5.6,45.8c5,16.9,16.9,33.7,16.9,34.3" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M425.4,247.9c0,0,0.3,26.3,3.4,41.3c4.5,21.8,12.5,33.1,15.5,37.1" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M420.5,254c0,0-1.7,23.5,2.2,40.4c5.6,23.8,14.9,35.4,14.9,35.4" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M415.5,262c0,0-2.3,19.1,0.2,34.1c3.2,19.2,9.9,31.5,11.9,38.7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M409.4,276.4c-0.9,11.2-1.4,22.5,0.9,33.5c0.7,3.3,1.6,6.5,2.6,9.6c2,6.9,4.1,13.8,6.1,20.7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M403.9,285c-1.3,9.4-2.6,19.1-0.8,28.5c0.5,2.9,1.4,5.7,2.1,8.6c1.7,6.9,2.8,14,3.8,21.1" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M396.6,295.5c-0.8,8.6,0.5,17.2,1.8,25.7c1.3,8.3,2.6,16.6,3.9,24.9" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M390.9,305.8c-3.2,14.8,2,29.9,2.5,45" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M384.9,315.3c-0.4,13.1,0.3,26.2,2.1,39.1" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M378.6,324.4c-0.8,12-0.9,24-0.2,35.9" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M373.7,331.7c-0.8,10.7-1,21.3-0.6,32" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M368.6,338c-0.4,9.6-0.8,19.1-1.2,28.7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M364.1,344.4c-0.3,8.9-1.3,17.8-3.1,26.6" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M359.4,350.7c-1.7,9.2-3.5,18.5-5.2,27.7" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M353.2,358c-1.1,8.2-2.1,16.4-3.2,24.6" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M349.2,362.8c-0.8,7.7-2.1,15.4-3.7,22.9" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

															<path class="st2" d="M344.4,366.4c-0.4,7.8-3.1,15.3-4.1,23" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; stroke-width: 2px;"/>

														</g>

													</g>

													<g>

														<path class="st4" d="M293.2,413.3c0.7,3,1.1,6.1,1.4,9.2c0.3,3.1,0.5,6.2,0.4,9.3c-0.7-3-1.1-6.1-1.4-9.2 C293.3,419.5,293.1,416.4,293.2,413.3z" style="fill: rgb(67, 112, 143);"/>

													</g>

													<line class="st5" x1="195" y1="312.5" x2="203.4" y2="317.4" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

													<line class="st5" x1="193.3" y1="320.8" x2="200.3" y2="324.8" style="fill: none; stroke: rgb(67, 112, 143); stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;"/>

												</g>

												<path id="wheel-down" d="M 2535.026 4098.539 H 2697.123 L 2697.123 4044.696 L 2865.168 4116.487 L 2697.123 4188.277 L 2697.123 4134.434 H 2535.026 V 4098.539 Z" style="stroke: rgb(65, 107, 146); stroke-linejoin: bevel; stroke-width: 7px; fill: rgb(255, 255, 255);" transform="matrix(-0.602916, 0.797805, -0.797805, -0.602916, 5457.286133, 1585.022217)" bx:shape="arrow 2535.026 4044.696 330.142 143.581 35.895 168.045 0 1@dbf8f4e0"/>

												<path id="wheel-up" d="M 2535.02 4098.529 H 2697.117 L 2697.117 4044.686 L 2865.162 4116.477 L 2697.117 4188.267 L 2697.117 4134.424 H 2535.02 V 4098.529 Z" style="stroke: rgb(65, 107, 146); stroke-linejoin: bevel; stroke-width: 7px; fill: rgb(255, 255, 255);" transform="matrix(0.652356, -0.757912, 0.757912, 0.652356, -3890.125732, 71.746422)" bx:shape="arrow 2535.02 4044.686 330.142 143.581 35.895 168.045 0 1@fdee07bb"/>

											</svg>



											<script>

											(function (window, document) {
												
												document.addEventListener("wheel", function(e) {
													let parent = document.getElementById("mouse");
													let child = e.target;
													if(parent.contains(child)) {
														e.preventDefault();
													}
												}, { passive: false });

												document.addEventListener('mousedown', function (e) {

													var buttons = e.buttons;



													if ((buttons & 1) === 1) {

														document.getElementById('mouse-1').classList.add('visited');

														document.getElementById('mouse-1').classList.add('active');

													}



													if ((buttons & 2) === 2) {

														document.getElementById('mouse-2').classList.add('visited');

														document.getElementById('mouse-2').classList.add('active');

													}



													if ((buttons & 4) === 4) {

														document.getElementById('mouse-3').classList.add('visited');

														document.getElementById('mouse-3').classList.add('active');

													}



													if ((buttons & 8) === 8) {

														document.getElementById('mouse-4').classList.add('visited');

														document.getElementById('mouse-4').classList.add('active');

													}



													if ((buttons & 16) === 16) {

														document.getElementById('mouse-5').classList.add('visited');

														document.getElementById('mouse-5').classList.add('active');

													}

												});



												document.addEventListener('mouseup', function () {

													[1, 2, 3, 4, 5].map(function (i) { return 'mouse-' + i; }).forEach(function (id) {

														document.getElementById(id).classList.remove('active');

													});

												});



												var mouseSection = document.querySelector('.mouse-section');

												mouseSection.addEventListener('contextmenu', function (e) { e.preventDefault() });

												mouseSection.addEventListener('mousedown', function (e) { e.preventDefault() });

												mouseSection.addEventListener('mouseup', function (e) { e.preventDefault() });



												var upId, downId;

												mouseSection.addEventListener('wheel', function (e) {

													if (e.deltaY < 0) {

														document.getElementById('wheel-down').classList.add('visited');

														document.getElementById('wheel-down').classList.add('active');

														window.clearTimeout(downId);

														downId = window.setTimeout(function () {

															document.getElementById('wheel-down').classList.remove('active')

														}, 250);

													} else if (e.deltaY > 0) {

														document.getElementById('wheel-up').classList.add('visited');

														document.getElementById('wheel-up').classList.add('active');

														window.clearTimeout(upId);

														upId = window.setTimeout(function () {

															document.getElementById('wheel-up').classList.remove('active')

														}, 250);

													}

												});

											})(window, document);

											</script>

										</div><!-- end .mouse-section -->

									</div>
								</div>
							</div>

							<div class="trouble-shooting">
								<div class="trouble-shooting-1 dis-flex">
									<div class="width-13 wid-xs-20"> 
										<div class="webcam-icon">
											<img class="tve_image" alt=""  src="<?php the_field('red_mouse_icon');?>" data-attachment-id="8509" width="64" height="64">
										</div>
									</div>
									<div class="width-87 wid-xs-80">
										<h3 class="ct-bold-text"><?php the_field('trouble-shooting_title');?></h3>
									</div>
								</div>

								<div class="trouble-shooting-2 dis-flex">
									<div class="width-33_3 wid-md-50 wid-xs-100">
										<div class="trouble-shooting-text-1 pd-1">
											<ul>
												<?php

												// check if the repeater field has rows of data
												if( have_rows('leftside_guide_list') ):

												 	// loop through the rows of data
									    		while ( have_rows('leftside_guide_list') ) : the_row();?>
												<li >
													<span class="fw-bold">
														<?php the_sub_field('left_side_list_title');?>
													</span>
												</li>
												<!-- <li >
													<span class="fw-bold">
														<font color="#595959"><span style="font-weight: normal;">If one or more of the relevant keys </span>don't light up <span style="font-weight: normal;">then that means that </span>your mouse failed the test!</font>
													</span>
												</li> -->
												<?php endwhile;
														else :
														endif;
														?>
											</ul>
										</div>

										<div align="center">
											<style>
											.OMT_MOINSBD_Middle { width: 300px; height: 250px; }
											@media(min-width: 500px) { .OMT_MOINSBD_Middle { width: 300px; height: 250px; } }
											@media(min-width: 800px) { .OMT_MOINSBD_Middle { width: 300px; height: 250px; } }
											</style>
										</div>

									</div>

									<div class="width-33_3 wid-md-50  wid-xs-100">
										<div class="trouble-shooting-text-1 pd-1">
											<ul>
												<li>
													<span class="fw-bold">
														<?php the_field('rightside_guide_list');?>
													</span>
												</li>
											</ul>
										</div>
									</div>

									<div class="width-33_3 md-hidden">
									</div>
								</div>
							</div>

							<div class="other-section">
								<?php 

								if( have_rows('links') ):

								while ( have_rows('links') ) : the_row();?>

								<div class="ct-row mic-settings-title">
									<span><?php the_sub_field('link_title');?></span>
								</div>

								<div class="mic-settings-section">
									<div class="mic-settings-menu width-50 wid-md-100">
										<ul>
											<?php

											// check if the repeater field has rows of data
											if( have_rows('link_table') ):

											// loop through the rows of data
											while ( have_rows('link_table') ) : the_row();?>
											<li class="dis-flex">

												<div class="webcam-icon">

													<img class="tve_image" alt=""  src="<?php the_field('mouse_icon');?>" data-attachment-id="8509" width="24" height="24" style="margin-right: 10px;">

												</div>
												<div>
													<a href="<?php the_sub_field('url');?>">
														<?php the_sub_field('link_desc');?></a>
												</div>

											</li>
											<?php endwhile;
											else :
											endif;
											?>
										</ul>
									</div>
								</div>

								<?php endwhile;
								else :
								endif;?>
								
								<div class="read-more-section">
									<div class="ct-row dis-flex">
										<div class="width-50 wid-xs-100">
											<div class="read-more-text-secction">
												<div class="read-more-title clearfix" >
														<h2><strong><?php the_field('more_about_title');?></strong></h2>
													</div>
													<?php

												// check if the repeater field has rows of data
												if( have_rows('test_content') ):

												 	// loop through the rows of data
									    		while ( have_rows('test_content') ) : the_row();?>
												<div class="read-more-1">
													

													<div class="read-more-subtitle clearfix">
														<h3 class="mar-bot-20"><?php the_sub_field('heading');?></h3>
													</div>

													<div class="read-more-text">
														<p><?php the_sub_field('descp');?>
														</p>
													</div>
												</div>
												<?php endwhile;
														else :
														endif;
														?>

												<!-- <div class="read-more-2 clearfix">

													<div class="read-more-subtitle clearfix">
														<h3 class="mar-bot-20">What mouse buttons can be tested with this test?</h3>
													</div>

													<div class="read-more-text">
														<p><span style="font-family: "Open Sans"; font-weight: 400;">The buttons that this page will check are 1 (left mouse button) 2 (middle mouse button) 3 (right mouse button) 4 (side button) and 5 (side button).<br><br> On uncoventional mouse layouts these numbers sometimes correspond to different buttons than the ones we mention here.</span></p>
													</div>
												</div>

												<div class="read-more-3 clearfix">
													<div class="read-more-subtitle clearfix">
														<h3 class="mar-bot-20">Does this test work on all browsers?</h3>
													</div>
													<div class="read-more-text">
														<p><span style="font-family: "Open Sans"; font-weight: 400;"><strong>Not yet, unfortunately.</strong> Some older browsers will not be able to record the "event" of some of the mouse clicks, and therefore only some of the buttons could be tested. <br><br>To test properly, use a modern browser like <strong>Chrome or Firefox</strong> (IE and Edge will not work 100% either).</span></p>
													</div>
												</div> -->
											</div>
										</div>

										<div class="width-50">
											<div class="img-section pad-left-15">
												<img class="lazyload" src="<?php the_field('rightside_image');?>" data-src="<?php the_field('rightside_image');?>"/>
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>

					</div>

				</article>

			</div>

		</div>
		<?php get_footer();